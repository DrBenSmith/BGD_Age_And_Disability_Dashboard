var figure = {
    "data": [
        {
            "meta": {
                "columnNames": {
                    "x": "B",
                    "y": "A"
                }
            },
            "mode": "markers",
            "name": "Male",
            "type": "bar",
            "xsrc": "Dr.Ben.Smith:0:790659",
            "x": [
                "",
                "10",
                "20",
                "30"
            ],
            "ysrc": "Dr.Ben.Smith:0:d83621",
            "y": [
                "",
                "hight",
                "width",
                "wieght"
            ],
            "orientation": "h"
        },
        {
            "meta": {
                "columnNames": {
                    "x": "C",
                    "y": "A"
                }
            },
            "name": "Female",
            "type": "bar",
            "xsrc": "Dr.Ben.Smith:0:80d153",
            "x": [
                "",
                "8",
                "24",
                "25"
            ],
            "ysrc": "Dr.Ben.Smith:0:d83621",
            "y": [
                "",
                "hight",
                "width",
                "wieght"
            ],
            "marker": {
                "color": "#ff7f0e"
            },
            "orientation": "h"
        }
    ],
    "layout": {
        "font": {
            "family": "Arial"
        },
        "title": {
            "x": 0.5,
            "font": {
                "color": "rgb(88, 88, 88)"
            },
            "text": "Disabled"
        },
        "xaxis": {
            "side": "bottom",
            "type": "linear",
            "range": [
                0,
                31.57894736842105
            ],
            "title": {
                "text": "Percentage (%)"
            },
            "showline": false,
            "autorange": true,
            "fixedrange": true,
            "rangeslider": {
                "range": [
                    0,
                    57.89473684210526
                ],
                "yaxis": {},
                "visible": false,
                "autorange": true
            }
        },
        "yaxis": {
            "side": "left",
            "type": "category",
            "dtick": 1,
            "range": [
                -0.5,
                3.5
            ],
            "tick0": 2,
            "ticks": "",
            "title": {
                "text": "Indicator"
            },
            "tickmode": "auto",
            "autorange": true,
            "automargin": false,
            "fixedrange": true
        },
        "legend": {
            "valign": "top",
            "xanchor": "left",
            "yanchor": "middle"
        },
        "barmode": "group",
        "modebar": {
            "orientation": "h"
        },
        "autosize": true,
        "bargroupgap": 0
    },
    "frames": []
}